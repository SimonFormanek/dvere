<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  echo $customer->get('greeting')
     . MODULE_NOTIFICATIONS_CREATE_ACCOUNT_WELCOME
     . MODULE_NOTIFICATIONS_CREATE_ACCOUNT_TEXT
     . MODULE_NOTIFICATIONS_CREATE_ACCOUNT_CONTACT
     . MODULE_NOTIFICATIONS_CREATE_ACCOUNT_WARNING;
?>