<li class="nav-item nb-special-offers">
  <?= '<a class="nav-link" href="' . tep_href_link('specials.php') . '">' . MODULE_NAVBAR_SPECIAL_OFFERS_PUBLIC_TEXT . '</a>' ?>
</li>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
