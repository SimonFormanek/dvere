<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

echo '<a class="navbar-brand nb-brand" href="' . tep_href_link('index.php') . '">' . MODULE_NAVBAR_BRAND_PUBLIC_TEXT . '</a>';
