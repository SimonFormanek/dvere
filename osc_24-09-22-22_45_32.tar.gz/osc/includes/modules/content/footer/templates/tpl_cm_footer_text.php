<div class="col-sm-6 col-md-<?php echo $content_width; ?> cm-footer-text">
  <h4><?php echo MODULE_CONTENT_FOOTER_TEXT_HEADING_TITLE; ?></h4>
  <?php echo MODULE_CONTENT_FOOTER_TEXT_TEXT; ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
