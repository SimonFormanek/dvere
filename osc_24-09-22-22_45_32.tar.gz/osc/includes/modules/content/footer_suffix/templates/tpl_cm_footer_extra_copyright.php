<div class="col-sm-<?php echo $content_width; ?> text-center text-sm-left cm-footer-extra-copyright">
  <?php echo FOOTER_TEXT_BODY; ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
