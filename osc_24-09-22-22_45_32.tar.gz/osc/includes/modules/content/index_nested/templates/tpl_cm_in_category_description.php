<div class="col-sm-<?= (int)MODULE_CONTENT_IN_CATEGORY_DESCRIPTION_CONTENT_WIDTH ?> cm-in-category-description">
  <div class="card mb-2 card-body">
    <?= $category_description ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
