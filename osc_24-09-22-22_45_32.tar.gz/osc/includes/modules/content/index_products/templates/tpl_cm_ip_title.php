<div class="col-sm-<?= (int)MODULE_CONTENT_IP_TITLE_CONTENT_WIDTH ?> title cm-ip-title">
  <h1 class="display-4"><?= sprintf(MODULE_CONTENT_IP_TITLE_PUBLIC_TITLE, $cm_name) ?></h1>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>