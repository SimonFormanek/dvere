<div class="col-sm-<?php echo $content_width; ?> cm-cs-title">
  <h1 class="display-4"><?php echo MODULE_CONTENT_CHECKOUT_SUCCESS_TITLE_PUBLIC_TITLE; ?></h1>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
   