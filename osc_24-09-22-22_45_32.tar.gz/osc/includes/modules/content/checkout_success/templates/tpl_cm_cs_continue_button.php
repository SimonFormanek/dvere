<div class="col-sm-<?php echo $content_width; ?> cm-cs-continue-button my-2">
  <?php 
  echo tep_draw_button(MODULE_CONTENT_CS_CONTINUE_BUTTON_TEXT, 'fas fa-thumbs-up', null, 'primary', null, 'btn-success btn-block btn-lg');
  ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
    