<div class="col-sm-<?php echo $content_width; ?> cm-gdpr-intro">
  <div class="alert alert-info">
    <?php echo MODULE_CONTENT_GDPR_INTRO_PUBLIC_TEXT; ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

