<div class="col-sm-<?php echo $content_width; ?> title cm-i-title">
  <h1 class="display-4"><?php echo sprintf(MODULE_CONTENT_I_TITLE_PUBLIC_TITLE, STORE_NAME); ?></h1>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
     