<div class="col-sm-<?php echo $content_width; ?> cm-i-customer-greeting">
  <div class="alert alert-info" role="alert">
    <?php echo $customer_greeting; ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
