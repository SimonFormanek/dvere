<div class="card mb-2 bm-manufacturers">
  <div class="card-header"><?php echo MODULE_BOXES_MANUFACTURERS_BOX_TITLE; ?></div>
  <?php echo $output; ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
