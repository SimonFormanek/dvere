<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE = 'Privacy Notice';

/*
Define the Title and Text of this page using the Info Pages Manager.
Admin > Tools > Info Pages
*/
