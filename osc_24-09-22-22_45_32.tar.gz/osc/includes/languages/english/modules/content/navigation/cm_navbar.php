<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_NAVBAR_TITLE', 'Navigation Bar');
  define('MODULE_CONTENT_NAVBAR_DESCRIPTION', 'Show the Navigation Bar on your site. <div class="alert alert-warning">This module has a number of Sub Modules which must also be installed.<br><br>Admin > Modules > Navbar Modules</div>');
  