<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_CS_CONTINUE_BUTTON_TITLE = 'Continue Button';
  const MODULE_CONTENT_CS_CONTINUE_BUTTON_DESCRIPTION = 'Shows the Continue Button.';
  
  const MODULE_CONTENT_CS_CONTINUE_BUTTON_TEXT = 'Your Order is Complete!  Continue Shopping';
