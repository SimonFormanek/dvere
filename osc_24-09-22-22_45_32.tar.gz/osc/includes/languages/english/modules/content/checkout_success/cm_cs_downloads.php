<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_TITLE', 'Product Downloads');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_DESCRIPTION', 'Show ordered product download links on the checkout success page');

  define('TABLE_HEADING_DOWNLOAD_DATE', 'Expiry date: ');
  define('TABLE_HEADING_DOWNLOAD_COUNT', ' downloads remaining');
  define('HEADING_DOWNLOAD', 'Download your products here:');
  define('FOOTER_DOWNLOAD', 'You can also download your products at a later time at \'%s\'');
?>
