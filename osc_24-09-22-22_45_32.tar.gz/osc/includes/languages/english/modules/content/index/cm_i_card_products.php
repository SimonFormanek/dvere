<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_CARD_PRODUCTS_TITLE       = 'New Products';
  const MODULE_CONTENT_CARD_PRODUCTS_DESCRIPTION = 'Shows the "New Products" module on your Index page.';
  
  const MODULE_CONTENT_CARD_PRODUCTS_HEADING     = 'New Products For %s';
   