<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_UPCOMING_PRODUCTS_TITLE                       = 'Upcoming Products';
  const MODULE_CONTENT_UPCOMING_PRODUCTS_DESCRIPTION                 = 'Shows the "Upcoming Products" module on your Index page.';
  
  const MODULE_CONTENT_UPCOMING_PRODUCTS_TABLE_HEADING_PRODUCTS      = 'Upcoming Products';
  const MODULE_CONTENT_UPCOMING_PRODUCTS_TABLE_HEADING_DATE_EXPECTED = 'Date Expected';
  