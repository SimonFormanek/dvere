<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_I_TITLE_TITLE        = 'Page Heading';
  const MODULE_CONTENT_I_TITLE_DESCRIPTION  = 'Shows the Page Heading.';
  
  const MODULE_CONTENT_I_TITLE_PUBLIC_TITLE = 'Welcome on %s';
  