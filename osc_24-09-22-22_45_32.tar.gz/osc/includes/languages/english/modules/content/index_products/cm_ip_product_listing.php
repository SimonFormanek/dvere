<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_IP_PRODUCT_LISTING_TITLE', 'Product Listing');
  define('MODULE_CONTENT_IP_PRODUCT_LISTING_DESCRIPTION', 'Show the Products listing for Category/Manufacturer.');
