<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_INFO_TEXT_TITLE = 'Text';
  const MODULE_CONTENT_INFO_TEXT_DESCRIPTION = 'Shows the Text of the Page';
