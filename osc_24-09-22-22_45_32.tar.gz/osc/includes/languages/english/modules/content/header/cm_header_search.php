<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_HEADER_SEARCH_TITLE', 'Search Box');
  define('MODULE_CONTENT_HEADER_SEARCH_DESCRIPTION', 'Adds your Search Box into the Header Area of your site.');
