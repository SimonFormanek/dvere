<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PINF_MESSAGE_TITLE             = 'Message';
  const MODULE_CONTENT_PINF_MESSAGE_DESCRIPTION       = 'Shows a Message on the product_info Page when the product is not available.';

  const MODULE_CONTENT_PINF_MESSAGE_PRODUCT_NOT_FOUND = 'D\'oh. Product not found!';
  