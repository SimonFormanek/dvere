<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_IN_CATEGORY_DESCRIPTION_TITLE', 'Category Description');
  define('MODULE_CONTENT_IN_CATEGORY_DESCRIPTION_DESCRIPTION', 'Show the category description in index.php');
  