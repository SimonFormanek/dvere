<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_IN_CATEGORY_LISTING_TITLE', 'Sub Category List');
  define('MODULE_CONTENT_IN_CATEGORY_LISTING_DESCRIPTION', 'If the Category has sub-categories, show them.');
