<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_DATE_AVAILABLE_TITLE       = 'Date Available';
  const MODULE_CONTENT_PI_DATE_AVAILABLE_DESCRIPTION = 'Shows the Date Available (if set) on the Product Info Page.';
 
  const MODULE_CONTENT_PI_DATE_AVAILABLE_TEXT        = 'Available from:<span class="badge badge-primary badge-pill">%s</span>';
