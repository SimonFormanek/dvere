<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_OA_TITLE         = 'Options & Attributes';
  const MODULE_CONTENT_PI_OA_DESCRIPTION   = 'Shows the Product Options on the product_info Page.';
  
  const MODULE_CONTENT_PI_OA_HEADING_TITLE = 'Available Options';
  
  const MODULE_CONTENT_PI_OA_ENFORCE_SELECTION = '--- Please Select ---';
