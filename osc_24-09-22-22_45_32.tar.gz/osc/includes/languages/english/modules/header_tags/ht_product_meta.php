<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_META_TITLE', 'Product SEO');
  define('MODULE_HEADER_TAGS_PRODUCT_META_DESCRIPTION', 'Add the SEO Meta elements defined when setting up the product, to the header of the product page');
  