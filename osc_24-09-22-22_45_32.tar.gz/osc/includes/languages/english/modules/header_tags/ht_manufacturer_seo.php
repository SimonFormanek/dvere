<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MANUFACTURERS_SEO_TITLE', 'Manufacturer SEO');
  define('MODULE_HEADER_TAGS_MANUFACTURERS_SEO_DESCRIPTION', 'Add the SEO elements you defined for the manufacturer, to the underlying code of the manufacturer page (aka Meta Description and Meta Keywords).  Good for SEO.');
  