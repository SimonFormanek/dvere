<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MAILCHIMP_360_TITLE', 'MailChimp E-Commerce 360');
  define('MODULE_HEADER_TAGS_MAILCHIMP_360_DESCRIPTION', '<i class="fas fa-info-circle"></i>&nbsp;<a href="https://mailchimp.com/" target="_blank" rel="noreferrer">Visit MailChimp Website</a><br><br>The MailChimp E-Commerce 360 module measures the ROI of your MailChimp e-mail campaigns');
?>
