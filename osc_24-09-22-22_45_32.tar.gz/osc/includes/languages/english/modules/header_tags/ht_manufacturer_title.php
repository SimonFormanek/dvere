<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MANUFACTURER_TITLE_TITLE', 'Manufacturer Title');
  define('MODULE_HEADER_TAGS_MANUFACTURER_TITLE_DESCRIPTION', 'Add the title of the current manufacturer to the page title');

  define('MODULE_HEADER_TAGS_MANUFACTURER_SEO_SEPARATOR', ' | ');
  