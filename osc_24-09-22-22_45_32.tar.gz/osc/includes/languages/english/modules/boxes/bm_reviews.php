<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Reviews');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Show product reviews');
  
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Reviews');
  