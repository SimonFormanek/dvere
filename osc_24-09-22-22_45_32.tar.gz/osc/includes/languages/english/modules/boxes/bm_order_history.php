<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2018 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_ORDER_HISTORY_TITLE', 'Order History');
  define('MODULE_BOXES_ORDER_HISTORY_DESCRIPTION', 'Show previously ordered products to signed in customers');
  define('MODULE_BOXES_ORDER_HISTORY_BOX_TITLE', 'Order History');
