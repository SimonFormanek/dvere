<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_CITY_TEXT_TITLE = 'City';
const MODULE_CUSTOMER_DATA_CITY_TEXT_DESCRIPTION = 'Show a city field in customer registration';

const ENTRY_CITY = 'City';
const ENTRY_CITY_ERROR = 'Your City must contain a minimum of %d characters.';
const ENTRY_CITY_TEXT = '';
