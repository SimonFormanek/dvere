<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_GENDER_TEXT_TITLE = 'Gender';
const MODULE_CUSTOMER_DATA_GENDER_TEXT_DESCRIPTION = 'Show a gender field in customer registration';

const MALE = 'Male';
const FEMALE = 'Female';

const ENTRY_GENDER = 'Gender';
const ENTRY_GENDER_ERROR = 'Please select your Gender.';
const ENTRY_GENDER_TEXT = '';
