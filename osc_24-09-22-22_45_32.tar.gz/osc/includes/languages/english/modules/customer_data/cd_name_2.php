<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_NAME_2_TEXT_TITLE = 'Two part name';
const MODULE_CUSTOMER_DATA_NAME_2_TEXT_DESCRIPTION = 'Show name (first, last) in customer data';
