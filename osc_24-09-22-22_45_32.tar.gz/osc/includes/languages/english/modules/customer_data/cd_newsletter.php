<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_NEWSLETTER_TEXT_TITLE = 'Newsletter';
const MODULE_CUSTOMER_DATA_NEWSLETTER_TEXT_DESCRIPTION = 'Show a newsletter field in customer registration';

const ENTRY_NEWSLETTER = 'Newsletter';
const ENTRY_NEWSLETTER_ERROR = 'There was an error with your newsletter submission';
const ENTRY_NEWSLETTER_TEXT = 'Subscribe to Newsletter';
