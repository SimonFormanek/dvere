<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_TELEPHONE_TEXT_TITLE = 'Telephone';
const MODULE_CUSTOMER_DATA_TELEPHONE_TEXT_DESCRIPTION = 'Show a telephone field in customer registration';

const ENTRY_TELEPHONE = 'Telephone';
const ENTRY_TELEPHONE_ERROR = 'Your Telephone must contain a minimum of %d characters.';
const ENTRY_TELEPHONE_TEXT = '';
