<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_COMPANY_TEXT_TITLE = 'Company';
const MODULE_CUSTOMER_DATA_COMPANY_TEXT_DESCRIPTION = 'Show a company field in customer registration';

const ENTRY_COMPANY = 'Company';
const ENTRY_COMPANY_ERROR = 'Your Company must contain a minimum of %d characters.';
const ENTRY_COMPANY_TEXT = '';
