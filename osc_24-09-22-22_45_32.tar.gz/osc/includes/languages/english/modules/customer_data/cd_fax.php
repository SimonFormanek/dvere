<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_FAX_TEXT_TITLE = 'Fax';
const MODULE_CUSTOMER_DATA_FAX_TEXT_DESCRIPTION = 'Show a fax field in customer registration';

const ENTRY_FAX = 'Fax';
const ENTRY_FAX_ERROR = 'Your Fax must contain a minimum of %d characters.';
const ENTRY_FAX_TEXT = '';
