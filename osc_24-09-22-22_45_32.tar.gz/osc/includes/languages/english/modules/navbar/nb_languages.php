<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_LANGUAGES_TITLE', 'Languages');
  define('MODULE_NAVBAR_LANGUAGES_DESCRIPTION', 'Show Languages in Navbar. <div class="alert alert-warning">If you have just one Language in your shop, there is no point installing this module.</div>');
  
  define('MODULE_NAVBAR_LANGUAGES_SELECTED_LANGUAGE', '<i title="Selected Language: English" class="fas fa-comment-dots"></i><span class="d-inline d-sm-none d-md-inline"> English</span> <span class="caret"></span>');
