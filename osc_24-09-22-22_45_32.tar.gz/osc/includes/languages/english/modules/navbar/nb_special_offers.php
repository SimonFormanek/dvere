<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_SPECIAL_OFFERS_TITLE', 'Special Offers');
  define('MODULE_NAVBAR_SPECIAL_OFFERS_DESCRIPTION', 'Show Special Offers Link in Navbar.');
  
  define('MODULE_NAVBAR_SPECIAL_OFFERS_PUBLIC_TEXT', '<i title="Special Offers" class="fas fa-fire"></i><span class="d-inline d-sm-none d-md-inline"> Special Offers</span>');
  