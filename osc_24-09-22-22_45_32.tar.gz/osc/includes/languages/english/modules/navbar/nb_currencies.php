<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_CURRENCIES_TITLE', 'Currencies');
  define('MODULE_NAVBAR_CURRENCIES_DESCRIPTION', 'Show Currencies in Navbar. <div class="alert alert-warning">If you have just one Currency in your shop, there is no point installing this module.</div>');
  
  define('MODULE_NAVBAR_CURRENCIES_SELECTED_CURRENCY', '<i title="Selected Currency: %1$s" class="fas fa-comments-dollar"></i><span class="d-inline d-sm-none d-md-inline"> %1$s</span> <span class="caret"></span>');
