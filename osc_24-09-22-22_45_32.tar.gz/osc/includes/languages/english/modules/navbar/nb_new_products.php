<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_NEW_PRODUCTS_TITLE', 'New Products');
  define('MODULE_NAVBAR_NEW_PRODUCTS_DESCRIPTION', 'Show New Products Link in Navbar.');
  
  define('MODULE_NAVBAR_NEW_PRODUCTS_PUBLIC_TEXT', '<i title="New Products" class="fas fa-list fa-fw"></i><span class="d-inline d-sm-none d-md-inline"> New Products</span>');
  