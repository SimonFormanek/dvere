<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_SHIPPING_ZONES_TEXT_TITLE = 'Zone Rates';
const MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION = 'Zone Based Rates';
const MODULE_SHIPPING_ZONES_TEXT_WAY = 'Shipping to %s : %d lb(s)';
const MODULE_SHIPPING_ZONES_INVALID_ZONE = 'No shipping available to the selected country';
const MODULE_SHIPPING_ZONES_UNDEFINED_RATE = 'The shipping rate cannot be determined at this time';
