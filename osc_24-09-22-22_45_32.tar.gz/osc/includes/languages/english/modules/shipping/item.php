<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ITEM_TEXT_TITLE', 'Per Item');
define('MODULE_SHIPPING_ITEM_TEXT_DESCRIPTION', 'Per Item');
define('MODULE_SHIPPING_ITEM_TEXT_WAY', '');
?>
