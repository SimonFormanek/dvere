<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE = 'Set up a Profile';

const HEADING_TITLE = 'My Profile Information';

const TEXT_ORIGIN_LOGIN = '<span class="text-danger"><strong>NOTE:</strong></span> If you have already set up a Profile, you can access your details at our <a class="alert-link" href="%s"><u>login page</u></a>.';
