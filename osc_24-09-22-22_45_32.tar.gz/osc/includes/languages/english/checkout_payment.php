<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Checkout');
define('NAVBAR_TITLE_2', 'Payment From You');

define('HEADING_TITLE', 'Payment From You');

define('TABLE_HEADING_BILLING_ADDRESS', 'Billing Address');

define('TABLE_HEADING_PAYMENT_METHOD', 'Payment Method');

define('TEXT_ENTER_PAYMENT_INFORMATION', 'This is currently the only payment method available to use on this order.');

define('BUTTON_CONTINUE_CHECKOUT_PROCEDURE', 'Continue Checkout');
