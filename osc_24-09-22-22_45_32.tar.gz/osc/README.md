# THIS REPOSITORY IS NOW DEFUNCT

Due to osCommerce' new ownership, we have taken the opportunity to break away from the osCommerce umbrella.   This means that we are able to supercharge our efforts to bring you our vision of e-Commerce with no hindrances of user bias, history or politics.

# New Repository 

[CE-PhoenixCart/PhoenixCart](https://github.com/CE-PhoenixCart/PhoenixCart)

<p align="center">
  <img src="https://raw.githubusercontent.com/gburton/Responsive-osCommerce/master/.github/ce-phoenix.png">
</p>

# New Forum

[CE-PhoenixCart/Forum](https://phoenixcart.org/forum/)

# Phoenix

Phoenix is a powerful ecommerce shop ready to use out of the box, putting you online and in full control of your business right from the start.  Your customers will love the modern, responsive design that will not only make your website look great on all mobile viewing devices but also perform at speed whilst giving you the power to create an individual and unique look to your shop with just a few clicks!

Phoenix is packed with many first class utilities as standard but its modular software design lets you add many more with no programming skills required. The full suite of product, shipping and payment options included will let you sell thousands of products in any number of categories worldwide in any currency or language providing a seamless customer experience.

# Demo Site

[CE-PhoenixCart/Demo](https://phoenixcart.org/demo/)

# Installation via Softaculous

<img align="left" src="http://www.softaculous.com/website/images/softac_products.gif"><br>CE Phoenix can now be installed easily with just one click via [Softaculous](http://www.softaculous.com/apps/ecommerce/CE_Phoenix)<br><br>

# Join the Phoenix Club

If you wish to help steer the future direction of the software please join the [Phoenix Forum](https://phoenixcart.org/forum/)
